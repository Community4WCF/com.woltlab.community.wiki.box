ALTER TABLE wcf1_navigation_item CHANGE itemID navigationItemID INT(10) NOT NULL AUTO_INCREMENT;
ALTER TABLE wcf1_navigation_item CHANGE item navigationItem VARCHAR(255) NOT NULL DEFAULT '';